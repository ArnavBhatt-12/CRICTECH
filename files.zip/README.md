# 🏏 CricTech — Cricket Bat Price Comparison

> Compare cricket bat prices across **Amazon**, **Flipkart** & brand websites — all in one place.

---

## 🌐 Live Demo

> After hosting on GitHub Pages, your link will be:
> **`https://YOUR-USERNAME.github.io/crictech`**

---

## ✨ Features

- 🔍 **Smart Search** — autocomplete with bat images
- 🎙️ **Voice Search** — bol ke search karo (Indian English)
- 📊 **Price Comparison** — Amazon vs Flipkart vs Brand Site
- 🟢 **Best Deal Highlight** — lowest price always in green
- 🎯 **Filters** — Brand, Type (EW/KW), Max Price slider
- ⬅️ **Back Navigation** — full page history
- 🛒 **All Platform Links** — every platform row is clickable
- 📱 **Responsive** — mobile + desktop

---

## 📁 Project Structure

```
crictech/
├── index.html          ← Main page (entry point)
├── css/
│   └── style.css       ← All styles
├── js/
│   ├── data.js         ← 30 bats dataset + platform config
│   └── app.js          ← Search, voice, filters, render logic
├── assets/
│   └── favicon.svg     ← Site icon
└── README.md
```

---

## 🚀 GitHub Pages pe Host Kaise Karo (Step by Step)

### Step 1 — GitHub pe new repository banao
1. [github.com/new](https://github.com/new) pe jao
2. Repository name: `crictech`
3. **Public** select karo
4. "Create repository" click karo

### Step 2 — Files upload karo
1. Repository mein **"uploading an existing file"** click karo
2. Saari files ek saath drag & drop karo:
   - `index.html`
   - `css/` folder
   - `js/` folder
   - `assets/` folder
   - `README.md`
3. **"Commit changes"** click karo

### Step 3 — GitHub Pages enable karo
1. Repository → **Settings** tab
2. Left sidebar mein **Pages** click karo
3. Source: **Deploy from a branch**
4. Branch: **main** → Folder: **/ (root)**
5. **Save** click karo

### Step 4 — Live link lo
- 2-3 minutes baad URL mil jaayega:
- `https://YOUR-USERNAME.github.io/crictech`

---

## ➕ Naya Bat Add Karna

`js/data.js` mein `bats` array mein add karo:

```js
{
  id: 31,
  name:  "New Bat Name",
  brand: "Brand",
  type:  "English Willow",   // ya "Kashmir Willow"
  img:   BRAND_IMG.MRF,      // ya koi bhi BRAND_IMG key
  prices: {
    Amazon:    { price: 5000, url: "https://www.amazon.in/s?k=bat+name" },
    Flipkart:  { price: 4800, url: "https://www.flipkart.com/search?q=bat+name" },
    "MRF.com": { price: 5200, url: "https://www.mrfsports.com/cricket/cricket-bats/" }
  }
}
```

---

## 🎨 Colors Change Karna

`css/style.css` mein `:root` variables edit karo:

```css
:root {
  --green: #00c853;   /* main accent */
  --dark:  #080d0a;   /* background  */
  --card:  #0f1610;   /* card bg     */
  --text:  #dff0e3;   /* main text   */
}
```

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Markup | HTML5 |
| Styling | CSS3 (custom properties, grid, flex) |
| Logic | Vanilla JavaScript (ES6+) |
| Fonts | Google Fonts (Bebas Neue, DM Sans, DM Mono) |
| Voice | Web Speech API |
| Hosting | GitHub Pages (free) |

---

## 📄 License

MIT — free to use and modify.
